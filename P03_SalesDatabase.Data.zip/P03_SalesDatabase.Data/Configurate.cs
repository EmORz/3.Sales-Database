﻿namespace P03_SalesDatabase.Data
{
    public class Configurate
    {
        public const string ConnectionString = @"Server=DESKTOP-CP2NEHV\SQLEXPRESS;Database=Sales;Integrated Security=True;";
    }
}